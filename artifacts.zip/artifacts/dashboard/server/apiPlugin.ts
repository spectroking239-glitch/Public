import type { Plugin, Connect } from "vite";
import { promises as fs } from "node:fs";
import { existsSync } from "node:fs";
import path from "node:path";
import Database from "better-sqlite3";

const ROOT = path.resolve(import.meta.dirname, "..", "..", "..");
const DB_FILE = path.join(ROOT, "services", "aerox-music", "database", "aerox_music.db");
const LIVE_STATS_FILE = path.join(ROOT, "services", "aerox-music", "database", "live_stats.json");

type LiveStats = {
  bot: {
    online: boolean;
    tag: string | null;
    id: string | null;
    avatarUrl: string | null;
    uptimeSeconds: number;
    startedAt: number;
    ping: number;
    guildCount: number;
    userCount: number;
  };
  commands: { slashCount: number; prefixCount: number };
  music: {
    activePlayers: number;
    playingNow: number;
    players: Array<{
      guildId: string;
      guildName: string;
      guildIcon: string | null;
      isPlaying: boolean;
      isPaused: boolean;
      volume: number;
      position: number;
      loop: string;
      queueLength: number;
      track: {
        title: string;
        author: string;
        length: number;
        uri: string;
        artworkUrl: string | null;
        requesterTag: string | null;
      } | null;
    }>;
  };
  guilds: Array<{
    id: string;
    name: string;
    iconUrl: string | null;
    memberCount: number;
  }>;
  generatedAt: number;
};

function offlineLiveStats(): LiveStats {
  return {
    bot: {
      online: false,
      tag: null,
      id: null,
      avatarUrl: null,
      uptimeSeconds: 0,
      startedAt: 0,
      ping: -1,
      guildCount: 0,
      userCount: 0,
    },
    commands: { slashCount: 0, prefixCount: 0 },
    music: { activePlayers: 0, playingNow: 0, players: [] },
    guilds: [],
    generatedAt: 0,
  };
}

async function readLiveStats(): Promise<LiveStats> {
  try {
    if (!existsSync(LIVE_STATS_FILE)) return offlineLiveStats();
    const raw = await fs.readFile(LIVE_STATS_FILE, "utf8");
    const parsed = JSON.parse(raw) as LiveStats;
    const stale = Date.now() - parsed.generatedAt > 30_000;
    if (stale) {
      return { ...parsed, bot: { ...parsed.bot, online: false } };
    }
    return parsed;
  } catch {
    return offlineLiveStats();
  }
}

type DbStats = {
  favorites: number;
  playlists: number;
  playlistTracks: number;
  noPrefixUsers: number;
  aiChatChannels: number;
  mentionRepliesEnabled: number;
  mentionRepliesDisabled: number;
  owners: number;
  topPlaylists: Array<{
    id: number;
    name: string;
    ownerId: string;
    trackCount: number;
  }>;
  topRequesters: Array<{ userId: string; count: number }>;
  recentPlaylists: Array<{
    id: number;
    name: string;
    ownerId: string;
    createdAt: string | null;
  }>;
};

function emptyDbStats(): DbStats {
  return {
    favorites: 0,
    playlists: 0,
    playlistTracks: 0,
    noPrefixUsers: 0,
    aiChatChannels: 0,
    mentionRepliesEnabled: 0,
    mentionRepliesDisabled: 0,
    owners: 0,
    topPlaylists: [],
    topRequesters: [],
    recentPlaylists: [],
  };
}

function safeCount(db: Database.Database, table: string): number {
  try {
    const row = db.prepare(`SELECT COUNT(*) AS c FROM ${table}`).get() as { c: number } | undefined;
    return row?.c ?? 0;
  } catch {
    return 0;
  }
}

function safeAll<T = unknown>(db: Database.Database, sql: string): T[] {
  try {
    return db.prepare(sql).all() as T[];
  } catch {
    return [];
  }
}

function readDbStats(): DbStats {
  if (!existsSync(DB_FILE)) return emptyDbStats();
  let db: Database.Database | null = null;
  try {
    db = new Database(DB_FILE, { readonly: true, fileMustExist: true });

    const favorites = safeCount(db, "Favorites");
    const playlists = safeCount(db, "Playlists");
    const playlistTracks = safeCount(db, "PlaylistTracks");
    const noPrefixUsers = safeCount(db, "NoPrefixes");
    const aiChatChannels = safeCount(db, "AiChatChannels");
    const owners = safeCount(db, "Owners");

    const mentionRepliesRows = safeAll<{ enabled: number; c: number }>(
      db,
      "SELECT enabled, COUNT(*) AS c FROM MentionReplySettings GROUP BY enabled",
    );
    let mentionRepliesEnabled = 0;
    let mentionRepliesDisabled = 0;
    for (const r of mentionRepliesRows) {
      if (r.enabled) mentionRepliesEnabled = r.c;
      else mentionRepliesDisabled = r.c;
    }

    const topPlaylists = safeAll<{
      id: number;
      name: string;
      ownerId: string;
      trackCount: number;
    }>(
      db,
      `SELECT p.id AS id, p.name AS name, p.ownerId AS ownerId,
              (SELECT COUNT(*) FROM PlaylistTracks pt WHERE pt.playlistId = p.id) AS trackCount
       FROM Playlists p
       ORDER BY trackCount DESC, p.id DESC
       LIMIT 8`,
    );

    const topRequesters = safeAll<{ userId: string; count: number }>(
      db,
      `SELECT ownerId AS userId, COUNT(*) AS count
       FROM Playlists
       GROUP BY ownerId
       ORDER BY count DESC
       LIMIT 6`,
    );

    const recentPlaylists = safeAll<{
      id: number;
      name: string;
      ownerId: string;
      createdAt: string | null;
    }>(
      db,
      `SELECT id, name, ownerId, createdAt
       FROM Playlists
       ORDER BY createdAt DESC
       LIMIT 6`,
    );

    return {
      favorites,
      playlists,
      playlistTracks,
      noPrefixUsers,
      aiChatChannels,
      mentionRepliesEnabled,
      mentionRepliesDisabled,
      owners,
      topPlaylists,
      topRequesters,
      recentPlaylists,
    };
  } catch {
    return emptyDbStats();
  } finally {
    db?.close();
  }
}

async function handleStats(_req: Connect.IncomingMessage, res: any) {
  const [live, db] = await Promise.all([readLiveStats(), Promise.resolve(readDbStats())]);
  const payload = {
    ...live,
    database: db,
    serverTime: Date.now(),
  };
  res.statusCode = 200;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.end(JSON.stringify(payload));
}

function send404(res: any) {
  res.statusCode = 404;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify({ error: "Not Found" }));
}

function trimBase(url: string, base: string | undefined): string {
  if (!base || base === "/") return url;
  const trimmed = base.endsWith("/") ? base.slice(0, -1) : base;
  if (url.startsWith(trimmed + "/")) return url.slice(trimmed.length);
  if (url === trimmed) return "/";
  return url;
}

export default function botApiPlugin(): Plugin {
  return {
    name: "yumi-bot-api",
    configureServer(server) {
      const base = server.config.base;
      server.middlewares.use(async (req, res, next) => {
        if (!req.url) return next();
        const stripped = trimBase(req.url, base);
        const pathname = stripped.split("?")[0];
        if (pathname === "/api/stats" || pathname === "/api/stats/") {
          try {
            await handleStats(req, res);
          } catch (err) {
            res.statusCode = 500;
            res.setHeader("Content-Type", "application/json");
            res.end(JSON.stringify({ error: "internal", detail: String(err) }));
          }
          return;
        }
        if (pathname.startsWith("/api/")) {
          send404(res);
          return;
        }
        next();
      });
    },
    configurePreviewServer(server) {
      const base = server.config.base;
      server.middlewares.use(async (req, res, next) => {
        if (!req.url) return next();
        const stripped = trimBase(req.url, base);
        const pathname = stripped.split("?")[0];
        if (pathname === "/api/stats" || pathname === "/api/stats/") {
          await handleStats(req, res);
          return;
        }
        if (pathname.startsWith("/api/")) {
          send404(res);
          return;
        }
        next();
      });
    },
  };
}
