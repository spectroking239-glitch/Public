export type Track = {
  title: string;
  author: string;
  length: number;
  uri: string;
  artworkUrl: string | null;
  requesterTag: string | null;
};

export type Player = {
  guildId: string;
  guildName: string;
  guildIcon: string | null;
  isPlaying: boolean;
  isPaused: boolean;
  volume: number;
  position: number;
  loop: string;
  queueLength: number;
  track: Track | null;
};

export type GuildSummary = {
  id: string;
  name: string;
  iconUrl: string | null;
  memberCount: number;
};

export type PlaylistSummary = {
  id: number;
  name: string;
  ownerId: string;
  trackCount: number;
};

export type RecentPlaylist = {
  id: number;
  name: string;
  ownerId: string;
  createdAt: string | null;
};

export type RequesterSummary = {
  userId: string;
  count: number;
};

export type StatsResponse = {
  bot: {
    online: boolean;
    tag: string | null;
    id: string | null;
    avatarUrl: string | null;
    uptimeSeconds: number;
    startedAt: number;
    ping: number;
    guildCount: number;
    userCount: number;
  };
  commands: {
    slashCount: number;
    prefixCount: number;
  };
  music: {
    activePlayers: number;
    playingNow: number;
    players: Player[];
  };
  guilds: GuildSummary[];
  database: {
    favorites: number;
    playlists: number;
    playlistTracks: number;
    noPrefixUsers: number;
    aiChatChannels: number;
    mentionRepliesEnabled: number;
    mentionRepliesDisabled: number;
    owners: number;
    topPlaylists: PlaylistSummary[];
    topRequesters: RequesterSummary[];
    recentPlaylists: RecentPlaylist[];
  };
  generatedAt: number;
  serverTime: number;
};

const API_BASE = `${import.meta.env.BASE_URL}api`;

export async function fetchStats(signal?: AbortSignal): Promise<StatsResponse> {
  const res = await fetch(`${API_BASE}/stats`, { signal, cache: "no-store" });
  if (!res.ok) {
    throw new Error(`Failed to load stats (${res.status})`);
  }
  return (await res.json()) as StatsResponse;
}

export function formatUptime(seconds: number): string {
  if (!seconds || seconds < 0) return "—";
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const parts: string[] = [];
  if (d) parts.push(`${d}d`);
  if (h || d) parts.push(`${h}h`);
  if (m || h || d) parts.push(`${m}m`);
  parts.push(`${s}s`);
  return parts.join(" ");
}

export function formatDuration(ms: number): string {
  if (!ms || ms < 0) return "0:00";
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function formatNumber(n: number): string {
  return new Intl.NumberFormat("en-US").format(n);
}
