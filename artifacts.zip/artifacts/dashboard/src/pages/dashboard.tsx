import { useQuery } from "@tanstack/react-query";
import { fetchStats, formatUptime, formatDuration, formatNumber } from "@/lib/api";
import { Bot, Activity, Users, Server, Disc, Music, Play, Pause, Hash, MessageSquare, Heart, PlaySquare, ListVideo, Crown, Clock, AlertTriangle, ShieldAlert, Sparkles, Zap, Key } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";

export default function Dashboard() {
  const { data, isLoading, isError } = useQuery({
    queryKey: ["stats"],
    queryFn: () => fetchStats(),
    refetchInterval: 5000,
  });

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  if (isError || !data) {
    return (
      <div className="min-h-screen bg-background p-8 flex items-center justify-center">
        <Card className="max-w-md w-full border-destructive/50 bg-destructive/10">
          <CardContent className="pt-6 flex flex-col items-center text-center space-y-4">
            <AlertTriangle className="h-12 w-12 text-destructive" />
            <h2 className="text-xl font-bold text-foreground">Connection Error</h2>
            <p className="text-muted-foreground">Could not reach the YUMI Music backend.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { bot, commands, music, guilds, database } = data;

  if (!bot.online) {
    return (
      <div className="min-h-screen bg-background p-8 flex items-center justify-center">
        <Card className="max-w-md w-full bg-card/50 border-border">
          <CardContent className="pt-6 flex flex-col items-center text-center space-y-4">
            <div className="relative">
              <Avatar className="h-24 w-24 border-4 border-muted opacity-50 grayscale">
                <AvatarImage src={bot.avatarUrl || ""} />
                <AvatarFallback>YM</AvatarFallback>
              </Avatar>
              <div className="absolute bottom-0 right-0 h-6 w-6 rounded-full bg-muted border-4 border-background" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground">Bot Offline</h2>
              <p className="text-muted-foreground">YUMI is currently disconnected from Discord.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground p-4 md:p-6 lg:p-8 font-sans selection:bg-primary/30">
      <div className="max-w-[1600px] mx-auto space-y-6">
        {/* Header: Bot Identity & Status */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-border/50">
          <div className="flex items-center gap-4">
            <div className="relative">
              <Avatar className="h-16 w-16 border-2 border-primary/50 shadow-[0_0_20px_rgba(0,229,255,0.4)]">
                <AvatarImage src={bot.avatarUrl || ""} />
                <AvatarFallback className="bg-primary/20 text-primary font-bold">YM</AvatarFallback>
              </Avatar>
              <div className="absolute bottom-0 right-0 h-4 w-4 rounded-full bg-green-500 border-2 border-background shadow-[0_0_10px_rgba(34,197,94,0.8)] animate-pulse" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary via-blue-400 to-secondary bg-clip-text text-transparent">
                {bot.tag || "YUMI Music"}
              </h1>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
                <span className="flex items-center gap-1.5 font-mono bg-card/50 px-2 py-0.5 rounded-md border border-border/50">
                  <Activity className="h-3 w-3 text-primary" /> {bot.ping}ms
                </span>
                <span className="flex items-center gap-1.5 font-mono bg-card/50 px-2 py-0.5 rounded-md border border-border/50">
                  <Clock className="h-3 w-3 text-secondary" /> {formatUptime(bot.uptimeSeconds)}
                </span>
                <span className="flex items-center gap-1.5 font-mono bg-card/50 px-2 py-0.5 rounded-md border border-border/50">
                  <Key className="h-3 w-3 text-amber-500" /> {database.owners} Owners
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-6 bg-card/30 p-3 rounded-xl border border-border/50 backdrop-blur-sm">
            <div className="text-right">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Total Servers</p>
              <p className="text-2xl font-bold font-mono text-foreground">{formatNumber(bot.guildCount)}</p>
            </div>
            <div className="h-10 w-px bg-border/50" />
            <div className="text-right">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Total Users</p>
              <p className="text-2xl font-bold font-mono text-foreground">{formatNumber(bot.userCount)}</p>
            </div>
          </div>
        </header>

        {/* Top Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-card/40 border-primary/20 backdrop-blur-md shadow-[0_0_20px_-10px_rgba(0,229,255,0.15)] hover:border-primary/40 transition-colors">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-xl text-primary shadow-[inset_0_0_10px_rgba(0,229,255,0.2)]">
                <Music className="h-6 w-6" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">Active Players</p>
                <p className="text-2xl font-bold font-mono text-primary">{formatNumber(music.activePlayers)}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card/40 border-secondary/20 backdrop-blur-md shadow-[0_0_20px_-10px_rgba(179,0,255,0.15)] hover:border-secondary/40 transition-colors">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-3 bg-secondary/10 rounded-xl text-secondary shadow-[inset_0_0_10px_rgba(179,0,255,0.2)]">
                <Disc className="h-6 w-6" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">Playing Now</p>
                <p className="text-2xl font-bold font-mono text-secondary">{formatNumber(music.playingNow)}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card/40 border-border/50 backdrop-blur-md hover:border-border transition-colors">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-3 bg-muted rounded-xl text-muted-foreground">
                <Hash className="h-6 w-6" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">Slash Cmds</p>
                <p className="text-2xl font-bold font-mono">{formatNumber(commands.slashCount)}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card/40 border-border/50 backdrop-blur-md hover:border-border transition-colors">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="p-3 bg-muted rounded-xl text-muted-foreground">
                <MessageSquare className="h-6 w-6" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">Prefix Cmds</p>
                <p className="text-2xl font-bold font-mono">{formatNumber(commands.prefixCount)}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Column: Music Players */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Music className="h-5 w-5 text-primary" /> Live Players
              </h2>
              <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                {music.players.length} Active
              </Badge>
            </div>
            
            {music.players.length === 0 ? (
              <Card className="bg-card/30 border-dashed border-border/50 border-2">
                <CardContent className="p-12 flex flex-col items-center text-center text-muted-foreground">
                  <Disc className="h-12 w-12 mb-4 opacity-20" />
                  <p>No active music players right now.</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {music.players.map((player) => (
                  <Card key={player.guildId} className="bg-card/40 border-border/40 overflow-hidden backdrop-blur-sm transition-all hover:bg-card/60 hover:border-primary/40 group shadow-sm">
                    <CardContent className="p-0">
                      <div className="flex flex-col sm:flex-row">
                        {/* Artwork */}
                        <div className="relative w-full sm:w-48 aspect-video sm:aspect-square bg-muted/20 shrink-0 overflow-hidden border-r border-border/30">
                          {player.track?.artworkUrl ? (
                            <img src={player.track.artworkUrl} className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105" alt="Artwork" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-muted/10">
                              <Music className="h-8 w-8 text-muted-foreground/30" />
                            </div>
                          )}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                          <div className="absolute bottom-3 left-3 flex items-center gap-2">
                            <Avatar className="h-6 w-6 border border-white/20 shadow-md">
                              <AvatarImage src={player.guildIcon || ""} />
                              <AvatarFallback className="text-[10px] bg-background text-foreground">{player.guildName.substring(0, 2)}</AvatarFallback>
                            </Avatar>
                            <span className="text-xs font-semibold text-white drop-shadow-md truncate max-w-[120px]">
                              {player.guildName}
                            </span>
                          </div>
                        </div>
                        
                        {/* Track Info */}
                        <div className="p-4 flex-1 flex flex-col justify-between">
                          <div>
                            <div className="flex items-start justify-between gap-4">
                              <div className="min-w-0">
                                <h3 className="font-bold text-lg truncate leading-tight group-hover:text-primary transition-colors" title={player.track?.title || "Unknown Track"}>
                                  {player.track?.title || "Unknown Track"}
                                </h3>
                                <p className="text-sm text-muted-foreground truncate">
                                  {player.track?.author || "Unknown Artist"}
                                </p>
                              </div>
                              <Badge variant={player.isPlaying ? "default" : "secondary"} className={`shrink-0 ${player.isPlaying ? "bg-primary/20 text-primary hover:bg-primary/30 border border-primary/30" : "bg-muted/50 border border-border/50"}`}>
                                {player.isPlaying ? <Play className="h-3 w-3 mr-1.5" /> : <Pause className="h-3 w-3 mr-1.5" />}
                                {player.isPlaying ? "Playing" : "Paused"}
                              </Badge>
                            </div>
                          </div>
                          
                          <div className="mt-4 space-y-2">
                            <div className="flex items-center justify-between text-xs font-mono text-muted-foreground">
                              <span>{formatDuration(player.position)}</span>
                              <span>{player.track ? formatDuration(player.track.length) : "0:00"}</span>
                            </div>
                            <Progress value={player.track && player.track.length > 0 ? (player.position / player.track.length) * 100 : 0} className="h-1.5 bg-muted/50">
                              <div className="h-full bg-gradient-to-r from-primary/80 to-primary transition-all duration-500 ease-linear shadow-[0_0_8px_rgba(0,229,255,0.5)]" style={{ width: `${player.track && player.track.length > 0 ? (player.position / player.track.length) * 100 : 0}%` }} />
                            </Progress>
                            <div className="flex items-center justify-between text-xs pt-1">
                              <span className="text-muted-foreground flex items-center gap-1.5">
                                <Users className="h-3 w-3" /> Req: {player.track?.requesterTag || "Unknown"}
                              </span>
                              <div className="flex items-center gap-3">
                                {player.volume !== 100 && (
                                  <span className="text-muted-foreground bg-muted/50 px-1.5 rounded">Vol: {player.volume}%</span>
                                )}
                                <span className="text-muted-foreground font-medium">
                                  {player.queueLength > 0 ? `+${player.queueLength} in queue` : "Queue empty"}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Database & Guilds */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex items-center gap-2 mb-4">
              <Server className="h-5 w-5 text-secondary" />
              <h2 className="text-xl font-bold">System Data</h2>
            </div>
            
            <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
              <CardContent className="p-4">
                <div className="grid grid-cols-2 gap-x-4 gap-y-4">
                  <StatItem icon={<Heart className="h-4 w-4 text-rose-500" />} label="Favorites" value={database.favorites} />
                  <StatItem icon={<ListVideo className="h-4 w-4 text-purple-500" />} label="Playlists" value={database.playlists} />
                  <StatItem icon={<PlaySquare className="h-4 w-4 text-blue-500" />} label="PL Tracks" value={database.playlistTracks} />
                  <StatItem icon={<Sparkles className="h-4 w-4 text-amber-400" />} label="AI Channels" value={database.aiChatChannels} />
                  <StatItem icon={<Zap className="h-4 w-4 text-yellow-500" />} label="No Prefix Users" value={database.noPrefixUsers} />
                  <StatItem icon={<MessageSquare className="h-4 w-4 text-green-500" />} label="Replies Enabled" value={database.mentionRepliesEnabled} />
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-6">
              <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                <CardHeader className="py-3 px-4 border-b border-border/50">
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <Crown className="h-4 w-4 text-yellow-500" /> Top Playlists
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[180px]">
                    {database.topPlaylists.length === 0 ? (
                      <p className="text-xs text-muted-foreground p-4 text-center">No playlists found.</p>
                    ) : (
                      <div className="flex flex-col divide-y divide-border/30">
                        {database.topPlaylists.slice(0, 10).map((pl, i) => (
                          <div key={pl.id} className="flex items-center justify-between text-sm p-3 hover:bg-muted/20 transition-colors">
                            <div className="flex items-center gap-3 min-w-0">
                              <span className="text-muted-foreground font-mono text-xs w-4 shrink-0 text-right">{i + 1}.</span>
                              <span className="truncate font-medium">{pl.name}</span>
                            </div>
                            <span className="text-xs text-muted-foreground font-mono bg-muted/50 px-2 py-0.5 rounded-full border border-border/50 shrink-0">
                              {pl.trackCount} tracks
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                <CardHeader className="py-3 px-4 border-b border-border/50">
                  <CardTitle className="text-sm font-semibold flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Server className="h-4 w-4 text-primary" /> Active Guilds
                    </div>
                    <Badge variant="secondary" className="text-xs bg-muted/50 font-mono">
                      {guilds.length}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[180px]">
                    <div className="flex flex-col divide-y divide-border/30">
                      {guilds.map((g) => (
                        <div key={g.id} className="flex items-center justify-between text-sm p-3 group hover:bg-muted/20 transition-colors">
                          <div className="flex items-center gap-3 min-w-0">
                            <Avatar className="h-7 w-7 border border-border/50">
                              <AvatarImage src={g.iconUrl || ""} />
                              <AvatarFallback className="text-[10px] bg-background text-foreground">{g.name.substring(0, 2)}</AvatarFallback>
                            </Avatar>
                            <span className="truncate font-medium group-hover:text-primary transition-colors">{g.name}</span>
                          </div>
                          <span className="text-xs text-muted-foreground flex items-center gap-1.5 font-mono shrink-0">
                            <Users className="h-3 w-3" /> {formatNumber(g.memberCount)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-6">
              <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                <CardHeader className="py-3 px-4 border-b border-border/50">
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <Users className="h-4 w-4 text-secondary" /> Top Requesters
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[150px]">
                    {database.topRequesters.length === 0 ? (
                      <p className="text-xs text-muted-foreground p-4 text-center">No data.</p>
                    ) : (
                      <div className="flex flex-col divide-y divide-border/30">
                        {database.topRequesters.slice(0, 5).map((req, i) => (
                          <div key={req.userId} className="flex items-center justify-between text-sm p-3 hover:bg-muted/20 transition-colors">
                            <div className="flex items-center gap-3 min-w-0">
                              <span className="text-muted-foreground font-mono text-xs w-4 shrink-0 text-right">{i + 1}.</span>
                              <span className="truncate font-medium font-mono text-xs">{req.userId}</span>
                            </div>
                            <span className="text-xs font-mono text-secondary bg-secondary/10 px-2 py-0.5 rounded-full shrink-0">
                              {req.count} reqs
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card className="bg-card/40 border-border/50 backdrop-blur-sm">
                <CardHeader className="py-3 px-4 border-b border-border/50">
                  <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" /> Recent Playlists
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[150px]">
                    {database.recentPlaylists.length === 0 ? (
                      <p className="text-xs text-muted-foreground p-4 text-center">No recent playlists.</p>
                    ) : (
                      <div className="flex flex-col divide-y divide-border/30">
                        {database.recentPlaylists.slice(0, 5).map((pl) => (
                          <div key={pl.id} className="flex flex-col text-sm p-3 hover:bg-muted/20 transition-colors gap-1">
                            <span className="truncate font-medium">{pl.name}</span>
                            <span className="text-xs text-muted-foreground font-mono">Owner: {pl.ownerId}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

function StatItem({ icon, label, value }: { icon: React.ReactNode, label: string, value: number }) {
  return (
    <div className="flex flex-col p-2 rounded-lg hover:bg-muted/30 transition-colors">
      <div className="flex items-center gap-2 mb-1">
        {icon}
        <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{label}</span>
      </div>
      <span className="text-xl font-bold font-mono pl-6">{formatNumber(value)}</span>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8 space-y-6">
      <div className="max-w-[1600px] mx-auto space-y-6">
        <header className="flex justify-between items-center pb-4 border-b border-border/10">
          <div className="flex items-center gap-4">
            <Skeleton className="h-16 w-16 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-8 w-48" />
              <Skeleton className="h-4 w-32" />
            </div>
          </div>
          <Skeleton className="h-14 w-64 rounded-xl" />
        </header>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-20 rounded-xl" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-7 space-y-4">
            <Skeleton className="h-8 w-48" />
            {[1, 2, 3].map(i => <Skeleton key={i} className="h-40 rounded-xl" />)}
          </div>
          <div className="lg:col-span-5 space-y-6">
            <Skeleton className="h-8 w-48" />
            <Skeleton className="h-[200px] rounded-xl" />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-1 gap-6">
              <Skeleton className="h-[240px] rounded-xl" />
              <Skeleton className="h-[240px] rounded-xl" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
