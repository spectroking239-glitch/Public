const {
  Events,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  MessageFlags,
  SeparatorSpacingSize,
} = require("discord.js");
const { askYumi, isAiAvailable, getRandomGif, shouldAddGif } = require("../helpers/aiHelper");
const MentionReplySetting = require("../../database/models/MentionReplySetting");

const MAX_REPLY_LEN = 1700;

module.exports = {
  name: Events.MessageCreate,
  async execute(message, client) {
    if (message.author.bot) return;
    if (!message.guild) return;

    if (!message.mentions.users.has(client.user.id)) return;
    if (message.type === 19) return;

    try {
      const enabled = await MentionReplySetting.isEnabled(message.guild.id);
      if (!enabled) return;
    } catch (err) {
      console.error('[MentionReply] setting lookup failed:', err?.message || err);
    }

    const mentionRegex = new RegExp(`<@!?${client.user.id}>`, 'g');
    const question = (message.content || '')
      .replace(mentionRegex, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!question) {
      const container = new ContainerBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `# 🎵 Hey there!\n\n• I'm **${client.user.username}** — your music companion\n• Use \`/help\` to see all my commands\n• Or mention me with a question and I'll answer!`
          )
        )
        .addSeparatorComponents(
          new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        )
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `Server admins can turn this off with \`/mention-reply off\`.`
          )
        );

      try {
        await message.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
        });
      } catch (err) {
        console.error('[MentionReply] welcome reply failed:', err?.message || err);
        await message.reply({ content: `Hey! I'm ${client.user.username}. Use \`/help\` to see what I can do.` }).catch(() => {});
      }
      return;
    }

    if (!isAiAvailable()) {
      await message.reply({
        content: 'My AI brain is not configured right now. Try `/help` to see what I can do!',
      }).catch(() => {});
      return;
    }

    try {
      if (message.channel?.sendTyping) {
        message.channel.sendTyping().catch(() => {});
      }
      let answer = await askYumi(question, message.author.username);
      if (answer.length > MAX_REPLY_LEN) {
        answer = answer.slice(0, MAX_REPLY_LEN) + '…';
      }
      if (shouldAddGif()) {
        answer = `${answer}\n${getRandomGif()}`;
      }
      await message.reply({ content: answer, allowedMentions: { repliedUser: true } });
    } catch (err) {
      console.error('[YUMI AI] reply failed:', err?.message || err);
      await message.reply({
        content: 'Sorry, I had trouble thinking of a reply. Please try again in a moment.',
      }).catch(() => {});
    }
  },
};
