const config = require('../config');
const Owner = require('../../database/models/Owner');

async function isOwner(userId) {
    if (!userId) return false;
    if (userId === config.OWNER_ID) return true;
    return Owner.isExtraOwner(userId);
}

const NOT_OWNER_MSG = 'This command can only be used by bot owners.';

module.exports = { isOwner, NOT_OWNER_MSG };
