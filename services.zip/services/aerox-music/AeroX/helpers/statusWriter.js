const fs = require('fs');
const path = require('path');

const STATUS_FILE = path.join(__dirname, '..', '..', 'database', 'live_stats.json');

let intervalHandle = null;

function buildSnapshot(client) {
    const players = [];
    if (client.poru?.players) {
        for (const [, player] of client.poru.players) {
            const guild = client.guilds.cache.get(player.guildId);
            const current = player.currentTrack?.info || null;
            players.push({
                guildId: player.guildId,
                guildName: guild?.name || 'Unknown Server',
                guildIcon: guild?.iconURL?.({ size: 128 }) || null,
                isPlaying: !!player.isPlaying,
                isPaused: !!player.isPaused,
                volume: player.volume ?? 100,
                position: player.position ?? 0,
                loop: player.loop || 'NONE',
                queueLength: Array.isArray(player.queue) ? player.queue.length : (player.queue?.size ?? 0),
                track: current
                    ? {
                          title: current.title,
                          author: current.author,
                          length: current.length,
                          uri: current.uri,
                          artworkUrl: current.artworkUrl || current.image || null,
                          requesterTag: current.requester?.tag || current.requester?.username || null,
                      }
                    : null,
            });
        }
    }

    let totalUsers = 0;
    for (const [, g] of client.guilds.cache) totalUsers += g.memberCount || 0;

    return {
        bot: {
            online: !!client.user,
            tag: client.user?.tag || null,
            id: client.user?.id || null,
            avatarUrl: client.user?.displayAvatarURL?.({ size: 256 }) || null,
            uptimeSeconds: Math.floor((client.uptime || 0) / 1000),
            startedAt: Date.now() - (client.uptime || 0),
            ping: client.ws?.ping ?? -1,
            guildCount: client.guilds.cache.size,
            userCount: totalUsers,
        },
        commands: {
            slashCount: client.commands?.size || 0,
            prefixCount: client.prefixCommands?.size || 0,
        },
        music: {
            activePlayers: players.length,
            playingNow: players.filter((p) => p.isPlaying && !p.isPaused).length,
            players,
        },
        guilds: client.guilds.cache.map((g) => ({
            id: g.id,
            name: g.name,
            iconUrl: g.iconURL?.({ size: 128 }) || null,
            memberCount: g.memberCount || 0,
        })),
        generatedAt: Date.now(),
    };
}

function writeSnapshot(client) {
    try {
        const snap = buildSnapshot(client);
        fs.writeFileSync(STATUS_FILE, JSON.stringify(snap, null, 2));
    } catch (err) {
        console.error('[statusWriter] write failed:', err?.message || err);
    }
}

function startStatusWriter(client, intervalMs = 5000) {
    if (intervalHandle) clearInterval(intervalHandle);
    writeSnapshot(client);
    intervalHandle = setInterval(() => writeSnapshot(client), intervalMs);
    intervalHandle.unref?.();
}

function stopStatusWriter() {
    if (intervalHandle) {
        clearInterval(intervalHandle);
        intervalHandle = null;
    }
}

module.exports = { startStatusWriter, stopStatusWriter, STATUS_FILE };
