const OpenAI = require('openai');

const baseURL = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;

let client = null;
if (baseURL && apiKey) {
    client = new OpenAI({ baseURL, apiKey });
}

const SYSTEM_PROMPT = `You are YUMI MUSIC, a friendly, expressive Discord bot. Your main purpose is playing music in voice channels, but you can also chat and answer any question users ask.

LANGUAGE RULES (very important):
- You may ONLY reply in English OR Manglish (Malayalam written in English/Latin letters, e.g. "ningalkku enthaanu venam?", "njan help cheyyam").
- NEVER use Malayalam script (no മ, ന, etc.). NEVER use any other language script (Hindi/Tamil/Arabic/Chinese, etc.).
- Match the user's language: if they write in English, reply in English. If they write in Manglish or Malayalam, reply in friendly Manglish.

PERSONALITY & STYLE:
- Be warm, playful, and expressive — like a fun friend, not a formal assistant.
- USE EMOJIS GENEROUSLY. Sprinkle 3–6 relevant emojis throughout every reply (music: 🎵🎶🎧🎤🎸🥁🎹 / mood: 😊😎🥰🤩🤗😂🔥💖✨ / actions: 👋👍🙌💃🕺 / ideas: 💡⭐🌟🎯). Place them naturally in the text, not all at the end.
- Open with a friendly emoji + greeting when the user just says hi.
- Keep replies concise (under 1500 characters), warm, and conversational. Use plain text — no markdown headings.

OTHER RULES:
- If asked who built or made you, say you are YUMI MUSIC. Never mention OpenAI, GPT, Anthropic, or any underlying model.
- If a user asks how to use you, briefly mention they can run /help to see all music commands.`;

async function askYumi(question, username) {
    if (!client) {
        throw new Error('AI client not configured');
    }
    const completion = await client.chat.completions.create({
        model: 'gpt-5.4',
        max_completion_tokens: 800,
        messages: [
            { role: 'system', content: SYSTEM_PROMPT },
            { role: 'user', content: `${username} asks: ${question}` },
        ],
    });
    const reply = completion.choices?.[0]?.message?.content?.trim();
    return reply || 'Sorry, I couldn\'t come up with an answer for that.';
}

const REPLY_GIFS = [
    'https://tenor.com/view/cat-vibing-cat-jamming-cat-vibing-to-music-cat-music-cat-headphones-gif-22167092',
    'https://tenor.com/view/dance-vibe-music-cool-cat-gif-15908793',
    'https://tenor.com/view/dance-music-vibe-happy-shake-gif-16745815',
    'https://tenor.com/view/music-headphones-cool-jamming-vibing-gif-25901453',
    'https://tenor.com/view/spongebob-spongebob-squarepants-music-headphones-jamming-gif-16213537',
    'https://tenor.com/view/cat-cute-kitty-funny-vibing-gif-23795320',
    'https://tenor.com/view/dancing-anime-dance-happy-cute-gif-17078648',
    'https://tenor.com/view/peace-out-bye-goodbye-see-you-later-anime-gif-17000516',
    'https://tenor.com/view/hello-hi-wave-cute-anime-gif-15916388',
    'https://tenor.com/view/cute-thumbs-up-anime-gif-26395802',
    'https://tenor.com/view/heart-love-anime-cute-blush-gif-19858604',
    'https://tenor.com/view/thinking-think-hmm-anime-cute-gif-23802189',
    'https://tenor.com/view/laugh-laughing-haha-funny-anime-gif-17157717',
    'https://tenor.com/view/ok-okay-thumbs-up-cool-anime-gif-21892826',
    'https://tenor.com/view/yes-yeah-nod-anime-cute-gif-22148893',
];

function getRandomGif() {
    return REPLY_GIFS[Math.floor(Math.random() * REPLY_GIFS.length)];
}

function shouldAddGif(probability = 0.4) {
    return Math.random() < probability;
}

module.exports = {
    askYumi,
    isAiAvailable: () => client !== null,
    getRandomGif,
    shouldAddGif,
};
