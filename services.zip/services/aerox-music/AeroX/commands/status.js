const { SlashCommandBuilder, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags, ActivityType } = require('discord.js');
const BotStatus = require('../../database/models/BotStatus');
const { isOwner, NOT_OWNER_MSG } = require('../helpers/ownerHelper');

const TYPE_MAP = {
    playing: ActivityType.Playing,
    listening: ActivityType.Listening,
    watching: ActivityType.Watching,
    competing: ActivityType.Competing,
    custom: ActivityType.Custom,
};

const PRESENCE_LABEL = {
    online: '🟢 Online',
    idle: '🌙 Idle',
    dnd: '⛔ Do Not Disturb',
    invisible: '⚫ Invisible',
};

const TYPE_LABEL = {
    playing: 'Playing',
    listening: 'Listening to',
    watching: 'Watching',
    competing: 'Competing in',
    custom: 'Custom',
};

async function applyStatus(client, { text, type, presence }) {
    const activityType = TYPE_MAP[type] ?? ActivityType.Playing;
    await client.user.setPresence({
        activities: [{ name: text, type: activityType }],
        status: presence,
    });
}

module.exports = {
    applyStatus,

    data: new SlashCommandBuilder()
        .setName('status')
        .setDescription('Change the bot\'s status (Owner only)')
        .setDefaultMemberPermissions('0')
        .addSubcommand(sub =>
            sub.setName('set')
                .setDescription('Set the bot status text and type')
                .addStringOption(o => o.setName('text').setDescription('Status text to display').setRequired(true).setMaxLength(128))
                .addStringOption(o => o.setName('type').setDescription('Activity type').setRequired(false).addChoices(
                    { name: 'Playing', value: 'playing' },
                    { name: 'Listening', value: 'listening' },
                    { name: 'Watching', value: 'watching' },
                    { name: 'Competing', value: 'competing' },
                    { name: 'Custom', value: 'custom' },
                ))
                .addStringOption(o => o.setName('presence').setDescription('Online / idle / dnd / invisible').setRequired(false).addChoices(
                    { name: 'Online', value: 'online' },
                    { name: 'Idle', value: 'idle' },
                    { name: 'Do Not Disturb', value: 'dnd' },
                    { name: 'Invisible', value: 'invisible' },
                ))
        )
        .addSubcommand(sub =>
            sub.setName('show').setDescription('Show the current bot status')
        ),

    async execute(interaction) {
        if (!await isOwner(interaction.user.id)) {
            return interaction.reply({ content: NOT_OWNER_MSG, ephemeral: true });
        }

        const sub = interaction.options.getSubcommand();

        if (sub === 'set') {
            const text = interaction.options.getString('text').trim();
            const type = interaction.options.getString('type') || 'playing';
            const presence = interaction.options.getString('presence') || 'online';

            await BotStatus.setCurrent({ text, type, presence });
            await applyStatus(interaction.client, { text, type, presence });

            const c = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Status Updated`))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `• **Type:** ${TYPE_LABEL[type]}\n• **Text:** ${text}\n• **Presence:** ${PRESENCE_LABEL[presence]}`
                ));

            return interaction.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
        }

        if (sub === 'show') {
            const current = await BotStatus.getCurrent();
            const c = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# 📡 Current Bot Status`))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));

            if (!current) {
                c.addTextDisplayComponents(new TextDisplayBuilder().setContent('_No custom status set. Bot is using its default presence._'));
            } else {
                c.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `• **Type:** ${TYPE_LABEL[current.type]}\n• **Text:** ${current.text}\n• **Presence:** ${PRESENCE_LABEL[current.presence]}`
                ));
            }

            return interaction.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
        }
    },
};
