const { SlashCommandBuilder, PermissionFlagsBits, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags, ChannelType } = require('discord.js');
const AiChatChannel = require('../../database/models/AiChatChannel');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ai-chat')
        .setDescription('Manage the AI chat channel for this server (Admins only)')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .setDMPermission(false)
        .addSubcommand(sub =>
            sub.setName('set')
                .setDescription('Set a channel where every message gets an AI reply')
                .addChannelOption(o => o.setName('channel').setDescription('Channel to use (defaults to current)').addChannelTypes(ChannelType.GuildText).setRequired(false))
        )
        .addSubcommand(sub =>
            sub.setName('unset').setDescription('Disable AI chat for this server')
        )
        .addSubcommand(sub =>
            sub.setName('status').setDescription('Show the current AI chat channel for this server')
        ),

    async execute(interaction) {
        if (!interaction.guild) {
            return interaction.reply({ content: 'This command can only be used in a server.', ephemeral: true });
        }
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild) &&
            !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                content: 'You need the **Manage Server** or **Administrator** permission to use this command.',
                ephemeral: true,
            });
        }

        const sub = interaction.options.getSubcommand();

        if (sub === 'set') {
            const channel = interaction.options.getChannel('channel') || interaction.channel;
            await AiChatChannel.setForGuild(interaction.guild.id, channel.id, interaction.user.id);

            const c = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# AI Chat Enabled`))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `• **Channel:** <#${channel.id}>\n• Every message in this channel will now get an AI reply.\n• Music commands (\`,play\`, \`/play\` etc.) still work normally here.`
                ));

            return interaction.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
        }

        if (sub === 'unset') {
            const existing = await AiChatChannel.getForGuild(interaction.guild.id);
            if (!existing) {
                return interaction.reply({ content: 'AI chat is not enabled in this server.', ephemeral: true });
            }
            await AiChatChannel.clearForGuild(interaction.guild.id);

            const c = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# AI Chat Disabled`))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `AI chat has been turned off for this server. Mention the bot directly to still get AI replies.`
                ));

            return interaction.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
        }

        if (sub === 'status') {
            const existing = await AiChatChannel.getForGuild(interaction.guild.id);
            const c = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# 🤖 AI Chat Status`))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true));

            if (!existing) {
                c.addTextDisplayComponents(new TextDisplayBuilder().setContent('AI chat is **not enabled** in this server.\nUse `/ai-chat set` to enable it.'));
            } else {
                c.addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `• **Channel:** <#${existing.channelId}>\n• **Set by:** <@${existing.setBy}>`
                ));
            }

            return interaction.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
        }
    },
};
