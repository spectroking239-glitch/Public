const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags,
} = require('discord.js');
const MentionReplySetting = require('../../database/models/MentionReplySetting');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mention-reply')
        .setDescription('Turn the bot mention auto-reply on or off (Admins only)')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .setDMPermission(false)
        .addSubcommand(sub =>
            sub.setName('on').setDescription('Enable replies when the bot is mentioned')
        )
        .addSubcommand(sub =>
            sub.setName('off').setDescription('Disable replies when the bot is mentioned')
        )
        .addSubcommand(sub =>
            sub.setName('status').setDescription('Show whether mention auto-reply is on or off')
        ),

    async execute(interaction) {
        if (!interaction.guild) {
            return interaction.reply({ content: 'This command can only be used in a server.', ephemeral: true });
        }

        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild) &&
            !interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({
                content: 'You need the **Manage Server** or **Administrator** permission to use this command.',
                ephemeral: true,
            });
        }

        const sub = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        if (sub === 'status') {
            const enabled = await MentionReplySetting.isEnabled(guildId);
            const c = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# 🔔 Mention Auto-Reply`))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `• Status: **${enabled ? 'ON' : 'OFF'}**\n• Use \`/mention-reply ${enabled ? 'off' : 'on'}\` to ${enabled ? 'disable' : 'enable'}.`
                ));
            return interaction.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
        }

        const enabled = sub === 'on';
        await MentionReplySetting.setEnabled(guildId, enabled, interaction.user.id);

        const c = new ContainerBuilder()
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# 🔔 Mention Auto-Reply ${enabled ? 'Enabled' : 'Disabled'}`))
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                enabled
                    ? `The bot will now reply when mentioned in this server.`
                    : `The bot will no longer reply when mentioned in this server.\nMusic commands and slash commands still work normally.`
            ));

        return interaction.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
    },
};
