const { SlashCommandBuilder, ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require('discord.js');
const Owner = require('../../database/models/Owner');
const { isOwner, NOT_OWNER_MSG } = require('../helpers/ownerHelper');
const config = require('../config');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('owner')
        .setDescription('Manage bot owners (Owner only)')
        .setDefaultMemberPermissions('0')
        .addSubcommand(sub =>
            sub.setName('add')
                .setDescription('Grant owner permissions to a user')
                .addStringOption(o => o.setName('userid').setDescription('Discord user ID').setRequired(true))
                .addStringOption(o => o.setName('name').setDescription('Display name for this owner').setRequired(true))
        )
        .addSubcommand(sub =>
            sub.setName('list').setDescription('List all bot owners')
        )
        .addSubcommand(sub =>
            sub.setName('remove')
                .setDescription('Revoke owner permissions from a user')
                .addStringOption(o => o.setName('userid').setDescription('Discord user ID').setRequired(true))
        ),

    async execute(interaction) {
        if (!await isOwner(interaction.user.id)) {
            return interaction.reply({ content: NOT_OWNER_MSG, ephemeral: true });
        }

        const sub = interaction.options.getSubcommand();

        if (sub === 'add') {
            const userId = interaction.options.getString('userid').trim();
            const name = interaction.options.getString('name').trim();

            if (!/^\d{17,20}$/.test(userId)) {
                return interaction.reply({ content: 'That is not a valid Discord user ID.', ephemeral: true });
            }
            if (userId === config.OWNER_ID) {
                return interaction.reply({ content: 'That user is already the primary bot owner.', ephemeral: true });
            }

            const existing = await Owner.findOne({ where: { userId } });
            if (existing) {
                return interaction.reply({ content: `**${existing.name}** is already an owner.`, ephemeral: true });
            }

            await Owner.create({
                userId,
                name,
                addedBy: interaction.user.id,
                addedByUsername: interaction.user.username,
            });

            const c = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Owner Added`))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `• **Name:** ${name}\n• **User ID:** \`${userId}\`\n• **Added by:** <@${interaction.user.id}>`
                ));

            return interaction.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
        }

        if (sub === 'list') {
            const owners = await Owner.findAll({ order: [['createdAt', 'ASC']] });
            const lines = [];
            lines.push(`• **Primary Owner:** <@${config.OWNER_ID}> \`${config.OWNER_ID}\``);
            if (owners.length === 0) {
                lines.push(`\n_No additional owners._`);
            } else {
                lines.push(`\n**Additional Owners (${owners.length}):**`);
                owners.forEach((o, i) => {
                    lines.push(`${i + 1}. **${o.name}** — <@${o.userId}> \`${o.userId}\``);
                });
            }

            const c = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# 👑 Bot Owners`))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(lines.join('\n')));

            return interaction.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
        }

        if (sub === 'remove') {
            const userId = interaction.options.getString('userid').trim();

            if (userId === config.OWNER_ID) {
                return interaction.reply({ content: 'You cannot remove the primary bot owner.', ephemeral: true });
            }

            const existing = await Owner.findOne({ where: { userId } });
            if (!existing) {
                return interaction.reply({ content: 'That user is not in the owners list.', ephemeral: true });
            }

            const removedName = existing.name;
            await existing.destroy();

            const c = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# Owner Removed`))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `• **Name:** ${removedName}\n• **User ID:** \`${userId}\``
                ));

            return interaction.reply({ components: [c], flags: MessageFlags.IsComponentsV2 });
        }
    },
};
