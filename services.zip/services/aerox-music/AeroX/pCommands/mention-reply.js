const {
    PermissionFlagsBits,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags,
} = require('discord.js');
const MentionReplySetting = require('../../database/models/MentionReplySetting');

module.exports = {
    name: 'mention-reply',
    aliases: ['mentionreply', 'mr'],
    description: 'Turn the bot mention auto-reply on or off (Admins only). Usage: ,mention-reply <on|off|status>',

    async execute(message, args) {
        if (!message.guild) {
            return message.reply({ content: 'This command can only be used in a server.' }).catch(() => {});
        }

        if (!message.member?.permissions.has(PermissionFlagsBits.ManageGuild) &&
            !message.member?.permissions.has(PermissionFlagsBits.Administrator)) {
            return message.reply({
                content: 'You need the **Manage Server** or **Administrator** permission to use this command.',
            }).catch(() => {});
        }

        const sub = (args[0] || 'status').toLowerCase();
        const guildId = message.guild.id;

        if (!['on', 'off', 'status'].includes(sub)) {
            return message.reply({ content: 'Usage: `,mention-reply <on|off|status>`' }).catch(() => {});
        }

        if (sub === 'status') {
            const enabled = await MentionReplySetting.isEnabled(guildId);
            const c = new ContainerBuilder()
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# 🔔 Mention Auto-Reply`))
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
                .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                    `• Status: **${enabled ? 'ON' : 'OFF'}**\n• Use \`,mention-reply ${enabled ? 'off' : 'on'}\` to ${enabled ? 'disable' : 'enable'}.`
                ));
            return message.reply({ components: [c], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }

        const enabled = sub === 'on';
        await MentionReplySetting.setEnabled(guildId, enabled, message.author.id);

        const c = new ContainerBuilder()
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# 🔔 Mention Auto-Reply ${enabled ? 'Enabled' : 'Disabled'}`))
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true))
            .addTextDisplayComponents(new TextDisplayBuilder().setContent(
                enabled
                    ? `The bot will now reply when mentioned in this server.`
                    : `The bot will no longer reply when mentioned in this server.\nMusic commands and slash commands still work normally.`
            ));

        return message.reply({ components: [c], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
    },
};
