const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');
const BaseModel = require('../BaseModel');

class MentionReplySetting extends BaseModel {
    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
                guildId: { type: DataTypes.STRING, allowNull: false, unique: true },
                enabled: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: true },
                changedBy: { type: DataTypes.STRING, allowNull: true },
            },
            {
                sequelize,
                modelName: 'MentionReplySetting',
                tableName: 'mention_reply_settings',
                timestamps: true,
            }
        );
        return this;
    }

    static async isEnabled(guildId) {
        const row = await this.findOne({ where: { guildId } });
        if (!row) return true;
        return row.enabled;
    }

    static async setEnabled(guildId, enabled, changedBy) {
        const existing = await this.findOne({ where: { guildId } });
        if (existing) {
            existing.enabled = enabled;
            existing.changedBy = changedBy;
            await existing.save();
            return existing;
        }
        return this.create({ guildId, enabled, changedBy });
    }
}

MentionReplySetting.init(sequelize);
module.exports = MentionReplySetting;
