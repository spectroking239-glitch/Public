const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');
const BaseModel = require('../BaseModel');

class Owner extends BaseModel {
    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
                userId: { type: DataTypes.STRING, allowNull: false, unique: true },
                name: { type: DataTypes.STRING, allowNull: false },
                addedBy: { type: DataTypes.STRING, allowNull: false },
                addedByUsername: { type: DataTypes.STRING, allowNull: false },
            },
            {
                sequelize,
                modelName: 'Owner',
                tableName: 'owners',
                timestamps: true,
            }
        );
        return this;
    }

    static async isExtraOwner(userId) {
        const record = await this.findOne({ where: { userId } });
        return !!record;
    }
}

Owner.init(sequelize);
module.exports = Owner;
