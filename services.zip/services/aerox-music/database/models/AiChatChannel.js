const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');
const BaseModel = require('../BaseModel');

class AiChatChannel extends BaseModel {
    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
                guildId: { type: DataTypes.STRING, allowNull: false, unique: true },
                channelId: { type: DataTypes.STRING, allowNull: false },
                setBy: { type: DataTypes.STRING, allowNull: false },
            },
            {
                sequelize,
                modelName: 'AiChatChannel',
                tableName: 'ai_chat_channels',
                timestamps: true,
            }
        );
        return this;
    }

    static async getForGuild(guildId) {
        return this.findOne({ where: { guildId } });
    }

    static async setForGuild(guildId, channelId, setBy) {
        const existing = await this.findOne({ where: { guildId } });
        if (existing) {
            existing.channelId = channelId;
            existing.setBy = setBy;
            await existing.save();
            return existing;
        }
        return this.create({ guildId, channelId, setBy });
    }

    static async clearForGuild(guildId) {
        return this.destroy({ where: { guildId } });
    }
}

AiChatChannel.init(sequelize);
module.exports = AiChatChannel;
