const { DataTypes } = require('sequelize');
const sequelize = require('../sequelize');
const BaseModel = require('../BaseModel');

class BotStatus extends BaseModel {
    static init(sequelize) {
        super.init(
            {
                id: { type: DataTypes.INTEGER, primaryKey: true },
                text: { type: DataTypes.STRING, allowNull: false },
                type: { type: DataTypes.STRING, allowNull: false, defaultValue: 'playing' },
                presence: { type: DataTypes.STRING, allowNull: false, defaultValue: 'online' },
            },
            {
                sequelize,
                modelName: 'BotStatus',
                tableName: 'bot_status',
                timestamps: true,
            }
        );
        return this;
    }

    static async getCurrent() {
        return this.findByPk(1);
    }

    static async setCurrent({ text, type, presence }) {
        const existing = await this.findByPk(1);
        if (existing) {
            existing.text = text;
            existing.type = type;
            existing.presence = presence;
            await existing.save();
            return existing;
        }
        return this.create({ id: 1, text, type, presence });
    }
}

BotStatus.init(sequelize);
module.exports = BotStatus;
